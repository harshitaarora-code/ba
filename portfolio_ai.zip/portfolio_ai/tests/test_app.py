"""Headless UI smoke test in demo mode (SYNTHETIC data)."""
import os
from streamlit.testing.v1 import AppTest

ROOT = os.path.dirname(os.path.dirname(__file__))


def test_pages_render_in_demo_mode(tmp_path, monkeypatch):
    monkeypatch.chdir(ROOT); monkeypatch.setenv("PFAI_DB_PATH", str(tmp_path / "ui.db")); monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    at = AppTest.from_file(os.path.join(ROOT, "app.py"), default_timeout=60).run()
    assert not at.exception
    # load demo via welcome button
    btn = [b for b in at.button if "demo portfolio" in b.label][0]; btn.click(); at.run()
    assert not at.exception
    for p in ["3 · Overview", "4 · Risk analysis", "5 · Stock explorer", "6 · Scenario lab", "7 · AI analyst", "8 · Reports", "9 · Settings & data status", "2 · Portfolio upload"]:
        at.sidebar.radio[0].set_value(p).run()
        assert not at.exception, (p, at.exception)
    at.sidebar.radio[0].set_value("6 · Scenario lab").run()
    run = [b for b in at.button if b.label == "Run addition"][0]; run.click(); at.run()
    assert not at.exception and len(at.session_state["scn"]) == 1
    at.sidebar.radio[0].set_value("7 · AI analyst").run()
    [b for b in at.button if b.label == "Analyse"][0].click(); at.run()
    assert not at.exception
