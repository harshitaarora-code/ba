"""All fixtures here are SYNTHETIC. Expected values are computed independently (hand maths / plain numpy / statsmodels)."""
import numpy as np, pandas as pd, pytest
import statsmodels.api as sm
from pfai import analytics as an, scenarios as sc, optimizer as opt, market_data as md, portfolio as pf, db, ai, demo

IDX = pd.bdate_range("2023-01-02", periods=400)


def synth(seed=1, n=400, k=3):
    rng = np.random.default_rng(seed)
    r = rng.normal(0.0005, 0.01, (n, k))
    p = 100 * np.cumprod(1 + r, axis=0)
    return pd.DataFrame(p, index=pd.bdate_range("2023-01-02", periods=n), columns=[f"S{i}.NS" for i in range(k)])


# 1 weights
def test_weights_known_values():
    v = pd.Series({"A": 600.0, "B": 300.0, "C": 100.0})
    w = an.weights_from_values(v)
    assert w.to_dict() == pytest.approx({"A": .6, "B": .3, "C": .1})
    c = an.concentration(w, {"A": "X", "B": "X", "C": "Y"})
    assert c["hhi"] == pytest.approx(.36 + .09 + .01) and c["effective_n"] == pytest.approx(1 / .46)
    assert c["top3"] == pytest.approx(1.0) and c["largest_sector"] == "X" and c["largest_sector_weight"] == pytest.approx(.9)


# 2/3 scenarios
def _ctx(p=None):
    p = synth() if p is None else p
    bench = (p.iloc[:, 0] * 0.5 + p.iloc[:, 1] * 0.5).rename("B")
    return sc.Context(p, bench, 0.06, {c: "S" for c in p.columns}, cost_bps=0)


def test_cash_addition_exact():
    ctx = _ctx(); v = pd.Series({"S0.NS": 500., "S1.NS": 500.})
    r = sc.simulate_addition(ctx, v, "S2.NS", 250.)
    assert r.after_values.sum() == pytest.approx(1250.)
    assert r.after["largest_weight"] == pytest.approx(0.4)
    assert r.before["n_holdings"] == 2 and r.after["n_holdings"] == 3


def test_costs_reduce_value():
    ctx = _ctx(); ctx.cost_bps = 100; v = pd.Series({"S0.NS": 500., "S1.NS": 500.})
    r = sc.simulate_addition(ctx, v, "S2.NS", 1000.)
    assert r.cost_inr == pytest.approx(10.) and r.after_values["S2.NS"] == pytest.approx(990.)


def test_sale_funded_replacement_conserves_value():
    ctx = _ctx(); v = pd.Series({"S0.NS": 600., "S1.NS": 400.})
    r = sc.simulate_replacement(ctx, v, {"S0.NS": 300.}, {"S2.NS": 1.0})
    assert r.after_values.sum() == pytest.approx(1000.)
    assert r.after_values["S0.NS"] == pytest.approx(300.) and r.after_values["S2.NS"] == pytest.approx(300.)


def test_replacement_with_costs_and_cash_and_validation():
    ctx = _ctx(); ctx.cost_bps = 50; v = pd.Series({"S0.NS": 600., "S1.NS": 400.})
    r = sc.simulate_replacement(ctx, v, {"S0.NS": 200.}, {"S2.NS": 1.0}, cash_fraction=0.5)
    assert r.cost_inr == pytest.approx(0.005 * (200 + 100))
    assert r.after_values[an.CASH] == pytest.approx(100.)
    with pytest.raises(ValueError):
        sc.simulate_replacement(ctx, v, {"S0.NS": 700.}, {"S2.NS": 1.0})
    with pytest.raises(ValueError):
        sc.simulate_replacement(ctx, v, {"S0.NS": 100.}, {"S2.NS": 0.5})
    with pytest.raises(ValueError):
        sc.simulate_addition(ctx, v, "NOPE.NS", 100.)


def test_compare_and_rank():
    ctx = _ctx(); v = pd.Series({"S0.NS": 900., "S1.NS": 100.})
    r = sc.simulate_addition(ctx, v, "S2.NS", 800.)
    cmp = sc.compare(r.before, r.after).set_index("metric")
    assert cmp.loc["largest_weight", "pp_change"] == pytest.approx((r.after["largest_weight"] - 0.9) * 100)
    assert cmp.loc["hhi", "abs_change"] < 0
    assert len(sc.rank_scenarios([r])) == 1


# 4/5 covariance, correlation, vol
def test_cov_corr_vol_match_numpy():
    r, _ = an.aligned_returns(synth())
    w = np.array([.5, .3, .2])
    assert an.covariance(r).values == pytest.approx(np.cov(r.values.T, ddof=1))
    assert an.correlation(r).values == pytest.approx(np.corrcoef(r.values.T))
    pr = r.values @ w
    assert an.annualized_vol(pd.Series(pr)) == pytest.approx(np.std(pr, ddof=1) * np.sqrt(252))
    assert an.portfolio_vol_cov(w, an.covariance(r)) == pytest.approx(an.annualized_vol(pd.Series(pr)))


# 6 beta (vs statsmodels OLS)
def test_beta_matches_ols():
    rng = np.random.default_rng(3); b = pd.Series(rng.normal(0, .01, 300)); a = 1.3 * b + rng.normal(0, .005, 300)
    ols = sm.OLS(a.values, sm.add_constant(b.values)).fit().params[1]
    assert an.beta(a, b) == pytest.approx(ols)


# 7 drawdown
def test_max_drawdown_known():
    s = pd.Series([100, 120, 90, 100, 130, 117], index=pd.bdate_range("2024-01-01", periods=6))
    d = an.max_drawdown(s)
    assert d["max_drawdown"] == pytest.approx(90 / 120 - 1)
    assert d["peak_date"] == s.index[1] and d["trough_date"] == s.index[2] and d["recovery_date"] == s.index[4]


# 8 sharpe + extras
def test_sharpe_known_and_zero_variance():
    r = pd.Series([0.01, -0.01, 0.02, 0.0, 0.005])
    rf = 0.0
    assert an.sharpe(r, rf) == pytest.approx(r.mean() / r.std(ddof=1) * np.sqrt(252))
    assert an.sharpe(pd.Series([0.001] * 10), 0.0) is None  # zero variance -> unavailable, not inf
    v, c = an.var_cvar(pd.Series(np.linspace(-0.05, 0.05, 101)), 0.95)
    assert v == pytest.approx(0.045) and c >= v


def test_risk_contributions_sum_to_one():
    r, _ = an.aligned_returns(synth())
    w = pd.Series([.5, .3, .2], index=r.columns)
    assert an.risk_contributions(w, an.covariance(r)).sum() == pytest.approx(1.0)


# 9 missing data
def test_misaligned_missing_data_not_filled():
    p = synth(k=2); p.iloc[10:15, 1] = np.nan
    r, _ = an.aligned_returns(p)
    assert len(r) < len(p) - 1 and not r.isna().any().any()
    m = an.portfolio_metrics(pd.Series([.5, .5], index=r.columns), r.iloc[:30], None, min_obs=120)
    assert any("unstable" in w for w in m["warnings"]) and m["beta"] is None
    assert "volatility" not in an.portfolio_metrics(pd.Series([1.0], index=r.columns[:1]), r.iloc[:1, :1], None)


# 10 ambiguous tickers / 11 empty YF
def _frame(n=30, end=None):
    end = end or pd.Timestamp.now().normalize()
    i = pd.bdate_range(end=end, periods=n)
    return pd.DataFrame({"Close": np.linspace(100, 110, n)}, index=i)


def test_ambiguous_ticker_requires_confirmation(monkeypatch):
    monkeypatch.setattr(md, "_raw_download", lambda **kw: _frame())
    r = md.resolve_symbol("ABC")
    assert r.status == "ambiguous" and r.yahoo_ticker is None and set(r.candidates) == {"ABC.NS", "ABC.BO"}
    assert md.resolve_symbol("ABC", "NSE").yahoo_ticker == "ABC.NS"
    assert md.resolve_symbol("ABC", confirmed="ABC.BO").status == "verified"


def test_empty_yahoo_response(monkeypatch):
    monkeypatch.setattr(md, "_raw_download", lambda **kw: pd.DataFrame())
    assert md.resolve_symbol("XYZ", "NSE").status == "unavailable"
    with pytest.raises(md.DataUnavailable):
        md.get_historical_prices("XYZ.NS")


def test_failure_falls_back_to_labelled_cache(monkeypatch, tmp_path):
    con = db.connect(str(tmp_path / "t.db"))
    monkeypatch.setattr(md, "_raw_download", lambda **kw: _frame(50))
    ok = md.get_historical_prices("AAA.NS", con=con)
    assert not ok.from_cache
    def boom(**kw): raise ConnectionError("down")
    monkeypatch.setattr(md, "_raw_download", boom)
    fb = md.get_historical_prices("AAA.NS", con=con, force_refresh=True)
    assert fb.stale_cache and any("unavailable" in w for w in fb.quality.warnings)
    with pytest.raises(md.DataUnavailable):
        md.get_historical_prices("BBB.NS", con=con, force_refresh=True)


# 12 stale
def test_stale_data_flagged():
    df, q = md.normalize_download(_frame(30, end=pd.Timestamp.now().normalize() - pd.Timedelta(days=40)), ["OLD.NS"])
    assert "OLD.NS" in q.stale and any("days old" in w for w in q.warnings)


# 13 adjusted prices: we request auto_adjust=True and use Close once (no second adjustment)
def test_uses_auto_adjust_and_close_only(monkeypatch):
    seen = {}
    def fake(**kw):
        seen.update(kw); f = _frame(40); f["Adj Close"] = f["Close"] * 0.5; return f
    monkeypatch.setattr(md, "_raw_download", fake)
    res = md.get_historical_prices("AAA.NS")
    assert seen["auto_adjust"] is True
    assert res.prices["AAA.NS"].iloc[-1] == pytest.approx(110.0)  # Close used, 'Adj Close' ignored


# 14 MultiIndex / multi-ticker / quality
def test_multiindex_and_cleaning():
    i = pd.bdate_range(end=pd.Timestamp.now().normalize(), periods=20)
    cols = pd.MultiIndex.from_product([["Close", "Volume"], ["A.NS", "B.NS"]], names=["Price", "Ticker"])
    raw = pd.DataFrame(np.random.default_rng(0).uniform(10, 20, (20, 4)), index=i, columns=cols)
    raw.loc[i[3], ("Close", "A.NS")] = -5
    raw = pd.concat([raw, raw.iloc[[5]]]).sort_index()   # duplicate date
    df, q = md.normalize_download(raw, ["A.NS", "B.NS"])
    assert list(df.columns) == ["A.NS", "B.NS"] and df.index.is_monotonic_increasing and not df.index.duplicated().any()
    assert q.duplicates_removed == 1 and q.invalid_removed == 1 and np.isnan(df.loc[i[3], "A.NS"])
    # single ticker MultiIndex (yfinance>=0.2.5x)
    one = raw.xs("A.NS", axis=1, level=1, drop_level=False)
    d1, _ = md.normalize_download(one, ["A.NS"])
    assert list(d1.columns) == ["A.NS"]
    # fundamentals: missing stays None
    f = md.normalize_fundamentals({"trailingPE": float("nan"), "longName": "X"}, "X.NS")
    assert f["trailing_pe"] is None and f["market_cap"] is None and f["name"] == "X"


# ingestion validation
def test_validation_flags_not_drops():
    df = pd.DataFrame({"symbol": ["TCS", "TCS", "", "INFY"], "exchange": ["NSE"] * 4, "quantity": [10, 5, 3, -1],
                       "avg_price": [100, 110, 5, "x"], "purchase_date": [None, None, "bad", None], "sector": [None] * 4, "currency": [None, None, None, "USD"]})
    v = pf.validate_holdings(df)
    assert len(v) == 4 and all(len(x) > 0 for x in v["issues"][[0, 1, 2, 3]])
    assert "Missing symbol" in v.at[2, "issues"] and "Invalid quantity" in v.at[3, "issues"]
    m = pf.merge_duplicates(v.iloc[:2])
    assert m.iloc[0]["quantity"] == 15 and m.iloc[0]["avg_price"] == pytest.approx((10 * 100 + 5 * 110) / 15)
    assert pf.suggest_mapping(["Instrument", "Qty.", "Avg. cost"])["quantity"] == "Qty."


# 16 optimizer
def test_optimizer_constraints_and_infeasible():
    r, _ = an.aligned_returns(synth(k=4)); cov = an.covariance(r); mu = r.mean() * 252
    res = opt.optimize(mu, cov, "min_variance", max_weight=0.4)
    assert res["status"] == "optimal" and res["weights"].sum() == pytest.approx(1) and res["weights"].max() <= 0.4 + 1e-6 and (res["weights"] >= -1e-9).all()
    assert opt.optimize(mu, cov, "max_sharpe", max_weight=0.5)["status"] == "optimal"
    assert opt.optimize(mu, cov, "mean_variance", max_weight=0.5)["status"] == "optimal"
    assert opt.optimize(mu, cov, "min_variance", max_weight=0.2)["status"] == "infeasible"
    secs = {c: "A" for c in mu.index}
    assert opt.optimize(mu, cov, "min_variance", sectors=secs, sector_limits={"A": 0.5})["status"] == "infeasible"
    # min-variance is at least as good as equal weight
    unconstrained = opt.optimize(mu, cov, "min_variance", max_weight=1.0)
    eq = np.ones(4) / 4
    assert unconstrained["volatility"] <= an.portfolio_vol_cov(eq, cov) + 1e-9
    assert unconstrained["volatility"] <= res["volatility"] + 1e-9


# 15 AI numerical consistency
def test_ai_number_validation_and_template_matches_tools(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    p, b = demo.synthetic_prices(400)
    ctx = sc.Context(p, b, 0.065, demo.sectors(), 0)
    v = pd.Series({"TCS.NS": 40 * p["TCS.NS"].iloc[-1], "HDFCBANK.NS": 100 * p["HDFCBANK.NS"].iloc[-1]})
    t = ai.AnalystTools(ctx, v)
    out = ai.ask("risks?", t)
    assert out["mode"] == "template" and "ANTHROPIC_API_KEY" in out["error"]
    facts = ai.flatten_numbers([l["output"] for l in t.log])
    assert ai.validate_numbers(" ".join(sum(out["report"].values(), [])), facts) == []
    assert ai.validate_numbers("Volatility is 87.31% and portfolio worth 99999999", facts) != []
    assert ai.validate_numbers("effective holdings 2.0", [2.0]) == []


# 17 user isolation
def test_user_data_isolation(tmp_path):
    con = db.connect(str(tmp_path / "iso.db"))
    pa = db.save_portfolio(con, "alice", "A", [{"yahoo_ticker": "TCS.NS", "quantity": 1}])
    pb = db.save_portfolio(con, "bob", "B", [{"yahoo_ticker": "INFY.NS", "quantity": 2}])
    assert [p["id"] for p in db.list_portfolios(con, "alice")] == [pa]
    assert db.load_holdings(con, "bob", pb)[0]["yahoo_ticker"] == "INFY.NS"
    with pytest.raises(PermissionError):
        db.load_holdings(con, "alice", pb)


def test_buy_and_hold_value_uses_fixed_quantities():
    p = synth(k=2); q = pd.Series({"S0.NS": 2.0, "S1.NS": 3.0})
    v = an.buy_and_hold_value(p, q)
    assert v.iloc[10] == pytest.approx(2 * p.iloc[10, 0] + 3 * p.iloc[10, 1])


def test_full_metrics_on_synthetic():
    p, b = demo.synthetic_prices(500)
    r, bb = an.aligned_returns(p, b)
    w = an.weights_from_values(pd.Series(1.0, index=p.columns))
    m = an.portfolio_metrics(w, r, bb, 0.065, demo.sectors())
    for k in ["volatility", "beta", "max_drawdown", "sharpe", "var", "cvar", "tracking_error", "capm_expected_return"]:
        assert m[k] is not None
    assert m["volatility"] == pytest.approx(m["volatility_cov"])
    assert m["max_drawdown"] < 0 and m["cvar"] >= m["var"]
