# Data sources and limitations
* **Source:** Yahoo Finance through the unofficial `yfinance` library. Free, unofficial, may be delayed, incomplete, rate-limited, change format, or break without notice. Not a real-time or executable quote.
* **Tickers:** NSE `.NS`, BSE `.BO`, indices e.g. `^NSEI`. A suffix alone proves nothing: every mapping is validated by a small download returning ≥3 valid dated, positive prices. Symbols valid on both exchanges are flagged **ambiguous** and need user confirmation. Validation confirms data exists, **not** that it is the company you intended (name match is not verified).
* **Fundamentals:** only fields returned by Yahoo; missing = missing (never 0); third-party, verify against official filings.
* **Freshness:** UI shows *last retrieval time* and *latest observation date* separately. Cache TTLs (historical 6h, latest 5m, fundamentals 24h, mappings 7d) are application settings, not Yahoo guarantees.
* **Failure:** on Yahoo failure the app shows the error, may fall back to a clearly labelled stale cache, and never substitutes fabricated prices. (Uploaded-price fallback is not implemented.)
* **Licensing:** the library being free does not grant commercial/redistribution rights. Review Yahoo's current terms and consider a licensed provider before commercial deployment.
