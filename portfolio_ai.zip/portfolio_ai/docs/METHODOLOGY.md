# Financial methodology

**Price series.** `yf.download(..., auto_adjust=True)`; the returned `Close` is split/dividend-adjusted and is the *only* series used (`Adj Close` ignored; no second adjustment). Dates normalised tz-naive, sorted, deduplicated (keep last); prices ≤ 0 or non-finite become missing. **No forward-fill.** Returns are computed only on dates where every series in the calculation has a valid price (inner alignment).

**Returns.** Simple daily return `P_t/P_{t-1} − 1`. Annualisation ×252 (vol: ×√252). CAGR uses calendar years of the window.

**Portfolio return convention (important).** Without transaction history, risk metrics use the *current* weights held constant (daily-rebalanced) over the window. This is a **hypothetical what-if, not a backtest of what you actually earned**. `analytics.buy_and_hold_value` computes true fixed-quantity buy-and-hold value for when quantities are known.

**Volatility** `std(r_p)·√252`; cross-checked against `√(252·wᵀΣw)` (tested equal). **Beta** `Cov(r,r_b)/Var(r_b)` on the same window. **Max drawdown** from the cumulative index `(1+r_p).cumprod()`, with peak/trough/recovery dates. **Sharpe** on excess of a compounded daily rf `(1+rf)^{1/252}−1` (user assumption, default 6.5%); returns *unavailable* when variance ≈ 0. **Sortino**: downside deviation of excess returns. **VaR/CVaR**: 1-day historical, reported as positive loss fractions at the chosen confidence (default 95%). **Tracking error / information ratio** vs the benchmark.

**Concentration.** `HHI=Σw²`, effective N `=1/HHI`, top-3/top-5, largest sector, sector HHI — descriptive, not risk scores. Risk contribution `w_i(Σw)_i/wᵀΣw` (sums to 1).

**Expected return.** Two separate labelled estimates: historical mean ×252, and CAPM `rf+β(E[R_m]−rf)` using historical benchmark mean. Neither is a forecast. Analyst/fundamental estimates are **not implemented**.

**Scenarios.** *Add with new cash:* value rises by amount − cost (a contribution, not performance). *Replace/reduce:* proceeds conserved except costs; cost = bps × (sell notional + buy notional), deducted from purchases; retained cash is zero-return/zero-risk. Before and after are evaluated on the **same observation window** (union of all involved tickers). Taxes, slippage, liquidity and impact are **not modelled**. Ranking score = −Σ w·relative change over volatility (0.4), HHI (0.3), top-sector weight (0.2), beta (0.1): rewards lower risk/concentration only; ignores returns/valuation.

**Optimiser.** SLSQP, long-only, Σw=1, max weight, optional sector caps and turnover; multi-start; infeasible problems are reported, never returned as weights. Inputs are historical estimates and are unstable — output is illustrative.

**Limitations.** Short windows give unstable estimates (flagged under 120 obs). Historical statistics do not predict the future. Correlation ≠ business similarity.
