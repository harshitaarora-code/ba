# Implementation report (honest status)

**Environment:** Python 3.12, yfinance 1.7.0, Streamlit 1.65. The build sandbox could **not reach Yahoo Finance**, so no live yfinance call has been executed. 

## Completed and verified by executed tests (25 passed, synthetic/mocked data)
Portfolio weights/concentration · cash-funded addition · sale-funded replacement (value conservation, costs, cash, input validation) · covariance/correlation vs numpy · annualised vol (two methods) · beta vs statsmodels OLS · max drawdown with dates · Sharpe (incl. zero-variance → unavailable) · VaR/CVaR · risk contributions · missing-data handling & unstable-window warnings · ambiguous-ticker handling · empty Yahoo response · stale-data flag · `auto_adjust=True`/Close-only · MultiIndex & duplicate/invalid cleaning · fundamentals missing≠0 · ingestion validation & duplicate merge · optimizer constraints/infeasibility · AI number validation & no-key fallback · user-data isolation · headless render of all 9 UI pages in demo mode (add scenario + AI page executed).

## Implemented but NOT verified live
* **yfinance calls** (`yf.download`, `Ticker.fast_info/info/history`) — written against the documented API and mocked in tests; real-world column layouts/field availability are unconfirmed. **First thing to do on your machine:** run Live mode with 2–3 tickers.
* **LLM path** (Anthropic tool-use loop + JSON report + number validation) — the validator is tested; the API loop was never run (no key/network). The default model name is configurable via `ANTHROPIC_MODEL`.
* **PDF export** generates (example in `docs/`), but layout was not visually reviewed.

## Partial / simplified
* Single-user local prototype: `user_id` is a placeholder, not authentication. DB access functions are user-scoped (tested), but the UI does not load saved portfolios back yet.
* Scenarios cover add, reduce-to-cash, replace (single/multiple buys, partial, cash). Metrics use constant current weights (hypothetical); drawdown is from that same reconstruction.
* `price_history`, `securities`, `scenarios`, `ai_reports` tables exist but are not populated by the UI (only portfolios, holdings, analysis runs/metrics and the cache are).
* Transaction costs are a flat bps assumption; taxes (STCG/LTCG), liquidity, slippage are not modelled.
* Sector comes from Yahoo `info` (Live) or the file; unavailable → "Unknown".
* Optimiser has no UI for sector/turnover constraints (supported in code).

## Not implemented
PostgreSQL · real authentication · uploaded-price fallback · analyst/fundamental expected-return model · NSE trading-calendar checks (gaps are reported, not judged) · rolling-beta/vol charts (functions exist) · latest-price caching using `CacheTTL.latest` · automated test of live Yahoo behaviour.
